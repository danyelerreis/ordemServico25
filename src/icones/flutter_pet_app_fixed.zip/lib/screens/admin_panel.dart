import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../providers/app_state.dart';

class AdminPanel extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthProvider>(context);
    if (!(auth.user?.isAdmin ?? false)) {
      return Scaffold(body: Center(child: Text('Acesso não autorizado')));
    }
    final app = Provider.of<AppState>(context);
    return Scaffold(
      appBar: AppBar(title: Text('Painel Admin')),
      body: Padding(
        padding: EdgeInsets.all(12),
        child: Column(
          children: [
            Text('Agendamentos', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Expanded(child: ListView.builder(itemCount: app.appointments.length, itemBuilder: (ctx, i){
              final a = app.appointments[i];
              return ListTile(
                title: Text('${a.id} - Pet:${a.petId}'),
                subtitle: Text(a.dateTime.toString()),
                trailing: IconButton(icon: Icon(Icons.delete), onPressed: () => app.removeAppointment(a.id)),
              );
            }))
          ],
        ),
      ),
    );
  }
}
