import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/service.dart';
import '../providers/app_state.dart';
import '../providers/auth_provider.dart';
import '../models/pet.dart';
import 'package:intl/intl.dart';

class AppointmentScreen extends StatefulWidget {
  @override
  State<AppointmentScreen> createState() => _AppointmentScreenState();
}

class _AppointmentScreenState extends State<AppointmentScreen> {
  DateTime? _selectedDate;
  TimeOfDay? _selectedTime;
  String? _petId;

  @override
  Widget build(BuildContext context) {
    final Service service = ModalRoute.of(context)!.settings.arguments as Service;
    final app = Provider.of<AppState>(context);
    final auth = Provider.of<AuthProvider>(context);
    final pets = app.pets;
    return Scaffold(
      appBar: AppBar(title: Text('Agendar: ${service.title}')),
      body: Padding(
        padding: EdgeInsets.all(12),
        child: Column(
          children: [
            DropdownButtonFormField<String>(
              items: pets.map((p) => DropdownMenuItem(value: p.id, child: Text(p.name))).toList(),
              onChanged: (v) => setState(()=> _petId = v),
              decoration: InputDecoration(labelText: 'Escolha o pet'),
              validator: (v) => v==null ? 'Escolha um pet' : null,
            ),
            SizedBox(height: 8),
            Row(children: [
              Expanded(child: Text(_selectedDate == null ? 'Data: não selecionada' : DateFormat('yyyy-MM-dd').format(_selectedDate!))),
              ElevatedButton(onPressed: () async {
                final today = DateTime.now();
                final dt = await showDatePicker(context: context, initialDate: today, firstDate: today, lastDate: today.add(Duration(days: 365)));
                if (dt != null) setState(()=> _selectedDate = dt);
              }, child: Text('Selecionar Data'))
            ]),
            SizedBox(height: 8),
            Row(children: [
              Expanded(child: Text(_selectedTime == null ? 'Hora: não selecionada' : _selectedTime!.format(context))),
              ElevatedButton(onPressed: () async {
                final t = await showTimePicker(context: context, initialTime: TimeOfDay.now());
                if (t != null) setState(()=> _selectedTime = t);
              }, child: Text('Selecionar Hora'))
            ]),
            Spacer(),
            ElevatedButton(onPressed: () {
              if (_petId==null || _selectedDate==null || _selectedTime==null) {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Preencha todos os campos')));
                return;
              }
              final dt = DateTime(_selectedDate!.year, _selectedDate!.month, _selectedDate!.day, _selectedTime!.hour, _selectedTime!.minute);
              if (!app.canSchedule(_petId!, service.id, dt)) {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Horário já reservado para este pet/serviço')));
                return;
              }
              final added = app.addAppointment(_petId!, service.id, dt, auth.user!.id);
              if (added) {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Agendamento confirmado para ' + DateFormat('yyyy-MM-dd HH:mm').format(dt))));
                Navigator.of(context).pop();
              } else {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Falha ao agendar')));
              }
            }, child: Text('Confirmar Agendamento'))
          ],
        ),
      ),
    );
  }
}
