import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../providers/app_state.dart';
import '../models/service.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthProvider>(context);
    final app = Provider.of<AppState>(context);
    return Scaffold(
      appBar: AppBar(
        title: Text('Serviços Pet'),
        actions: [
          IconButton(onPressed: () => Navigator.of(context).pushNamed('/services'), icon: Stack(
            children: [
              Icon(Icons.list),
              if (app.favorites.isNotEmpty) Positioned(right:0, child: CircleAvatar(radius:6, child: Text('${app.favorites.length}', style: TextStyle(fontSize:8)))),
            ],
          )),
          IconButton(onPressed: () {
            if (auth.user?.isAdmin ?? false) Navigator.of(context).pushNamed('/admin');
            else ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Acesso de administrador necessário')));
          }, icon: Icon(Icons.admin_panel_settings)),
          IconButton(onPressed: () {
            Provider.of<AuthProvider>(context, listen:false).logout();
            Navigator.of(context).pushReplacementNamed('/login');
          }, icon: Icon(Icons.logout)),
        ],
      ),
      body: LayoutBuilder(
        builder: (ctx, constraints) {
          final wide = constraints.maxWidth > 800;
          return Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: [
                Row(children: [
                  Expanded(child: Text('Bem-vindo, ${auth.user?.name ?? 'Convidado'}', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
                  ElevatedButton.icon(onPressed: () => Navigator.of(context).pushNamed('/pet_form'), icon: Icon(Icons.pets), label: Text('Cadastrar Pet'))
                ]),
                SizedBox(height: 12),
                Expanded(
                  child: GridView.count(
                    crossAxisCount: wide ? 3 : 1,
                    crossAxisSpacing: 8,
                    mainAxisSpacing: 8,
                    children: app.services.map((s) => ServiceCard(service: s)).toList(),
                  ),
                )
              ],
            ),
          );
        },
      ),
    );
  }
}

class ServiceCard extends StatelessWidget {
  final Service service;
  ServiceCard({required this.service});
  @override
  Widget build(BuildContext context) {
    final app = Provider.of<AppState>(context);
    final favorited = app.favorites.contains(service.id);
    return Card(
      child: Padding(
        padding: EdgeInsets.all(8),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text(service.title, style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            IconButton(
              icon: Icon(favorited ? Icons.favorite : Icons.favorite_border),
              onPressed: () => app.toggleFavorite(service.id),
            )
          ]),
          Text(service.description),
          Spacer(),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text('R\$ ${service.price.toStringAsFixed(2)}'),
            ElevatedButton(onPressed: () => Navigator.of(context).pushNamed('/service_detail', arguments: service), child: Text('Detalhe'))
          ])
        ]),
      ),
    );
  }
}
