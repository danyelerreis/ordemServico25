import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_state.dart';
import '../models/service.dart';

class ServiceListScreen extends StatefulWidget {
  @override
  State<ServiceListScreen> createState() => _ServiceListScreenState();
}

class _ServiceListScreenState extends State<ServiceListScreen> {
  String query = '';

  @override
  Widget build(BuildContext context) {
    final app = Provider.of<AppState>(context);
    final services = app.services.where((s) => s.title.toLowerCase().contains(query.toLowerCase())).toList();
    return Scaffold(
      appBar: AppBar(title: Text('Serviços'),),
      body: Column(
        children: [
          Padding(
            padding: EdgeInsets.all(8),
            child: TextField(
              decoration: InputDecoration(labelText: 'Pesquisar serviços', prefixIcon: Icon(Icons.search)),
              onChanged: (v) => setState(()=> query = v),
            ),
          ),
          Expanded(child: ListView.builder(itemCount: services.length, itemBuilder: (ctx, i){
            final s = services[i];
            return ListTile(
              title: Text(s.title),
              subtitle: Text(s.description),
              trailing: Text('R\$ ${s.price.toStringAsFixed(2)}'),
              onTap: () => Navigator.of(context).pushNamed('/service_detail', arguments: s),
            );
          }))
        ],
      ),
    );
  }
}
