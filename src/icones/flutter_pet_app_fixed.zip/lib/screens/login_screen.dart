import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';

class LoginScreen extends StatefulWidget {
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  String _email = '';
  String _password = '';
  bool _loading = false;

  void _submit() async {
    if (!_formKey.currentState!.validate()) return;
    _formKey.currentState!.save();
    setState((){ _loading = true; });
    final auth = Provider.of<AuthProvider>(context, listen: false);
    final ok = await auth.login(_email.trim(), _password.trim());
    setState((){ _loading = false; });
    if (ok) {
      Navigator.of(context).pushReplacementNamed('/home');
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Credenciais inválidas')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final mq = MediaQuery.of(context);
    final isWide = mq.size.width > 600;
    return Scaffold(
      body: Center(
        child: Card(
          margin: EdgeInsets.all(16),
          child: Container(
            width: isWide ? 480 : double.infinity,
            padding: EdgeInsets.all(16),
            child: Form(
              key: _formKey,
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Text('Entrar', style: Theme.of(context).textTheme.titleLarge),
                SizedBox(height: 8),
                TextFormField(
                  decoration: InputDecoration(labelText: 'E-mail'),
                  initialValue: 'usuario@gmail.com',
                  validator: (v) => (v == null || !v.contains('@')) ? 'Informe um e-mail válido' : null,
                  onSaved: (v) => _email = v ?? '',
                ),
                TextFormField(
                  decoration: InputDecoration(labelText: 'Senha'),
                  obscureText: true,
                  initialValue: 'user123',
                  validator: (v) => (v == null || v.length < 4) ? 'Senha muito curta' : null,
                  onSaved: (v) => _password = v ?? '',
                ),
                SizedBox(height: 12),
                _loading ? CircularProgressIndicator() : ElevatedButton(onPressed: _submit, child: Text('Entrar')),
                SizedBox(height: 8),
                Text('Use admin@gmail.com/admin123 for admin, usuario@gmail.com/user123 for user', textAlign: TextAlign.center, style: TextStyle(fontSize: 12)),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}
