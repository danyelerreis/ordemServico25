import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/service.dart';
import '../providers/app_state.dart';
import '../providers/auth_provider.dart';

class ServiceDetailScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final Service service = ModalRoute.of(context)!.settings.arguments as Service;
    final app = Provider.of<AppState>(context);
    final auth = Provider.of<AuthProvider>(context);
    return Scaffold(
      appBar: AppBar(title: Text(service.title)),
      body: Padding(
        padding: EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(service.description),
          SizedBox(height: 8),
          Text('Duração: ${service.duration.inMinutes} minutos'),
          SizedBox(height: 8),
          Text('Preço: R\$ ${service.price.toStringAsFixed(2)}'),
          Spacer(),
          ElevatedButton.icon(
            onPressed: () {
              if (!auth.isAuthenticated) {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Faça login para agendar')));
                return;
              }
              Navigator.of(context).pushNamed('/appointment', arguments: service);
            },
            icon: Icon(Icons.event_available),
            label: Text('Agendar')
          )
        ]),
      ),
    );
  }
}
