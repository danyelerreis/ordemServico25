import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';
import '../models/pet.dart';
import '../providers/app_state.dart';

class PetFormScreen extends StatefulWidget {
  final Pet? pet;
  PetFormScreen({this.pet});
  @override
  State<PetFormScreen> createState() => _PetFormScreenState();
}

class _PetFormScreenState extends State<PetFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _uuid = Uuid();
  String name = '';
  String species = '';
  String breed = '';
  int age = 0;
  double weight = 0;
  String photoUrl = '';

  @override
  void initState() {
    super.initState();
    final p = widget.pet;
    if (p != null) {
      name = p.name; species = p.species; breed = p.breed; age = p.age; weight = p.weight; photoUrl = p.photoUrl;
    }
  }

  void _save() {
    if (!_formKey.currentState!.validate()) return;
    _formKey.currentState!.save();
    final app = Provider.of<AppState>(context, listen:false);
    if (widget.pet == null) {
      final pet = Pet(id: _uuid.v4(), name: name, species: species, breed: breed, age: age, weight: weight, photoUrl: photoUrl);
      app.addPet(pet);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Pet cadastrado')));
    } else {
      final pet = Pet(id: widget.pet!.id, name: name, species: species, breed: breed, age: age, weight: weight, photoUrl: photoUrl);
      app.updatePet(pet);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Pet atualizado')));
    }
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.pet==null ? 'Cadastrar Pet' : 'Editar Pet')),
      body: Padding(
        padding: EdgeInsets.all(12),
        child: Form(
          key: _formKey,
          child: ListView(children: [
            TextFormField(decoration: InputDecoration(labelText:'Nome'), initialValue: name, validator: (v)=> v==null || v.isEmpty ? 'Informe o nome' : null, onSaved: (v)=> name = v ?? ''),
            TextFormField(decoration: InputDecoration(labelText:'Espécie'), initialValue: species, validator: (v)=> v==null || v.isEmpty ? 'Informe a espécie' : null, onSaved: (v)=> species = v ?? ''),
            TextFormField(decoration: InputDecoration(labelText:'Raça'), initialValue: breed, onSaved: (v)=> breed = v ?? ''),
            TextFormField(decoration: InputDecoration(labelText:'Idade (anos)'), initialValue: age==0 ? '' : age.toString(), keyboardType: TextInputType.number, validator: (v)=> v==null || int.tryParse(v)==null ? 'Informe a idade' : null, onSaved:(v)=> age = int.parse(v!)),
            TextFormField(decoration: InputDecoration(labelText:'Peso (kg)'), initialValue: weight==0 ? '' : weight.toString(), keyboardType: TextInputType.number, validator: (v)=> v==null || double.tryParse(v)==null ? 'Informe o peso' : null, onSaved:(v)=> weight = double.parse(v!)),
            TextFormField(decoration: InputDecoration(labelText:'Foto (URL)'), initialValue: photoUrl, onSaved:(v)=> photoUrl = v ?? ''),
            SizedBox(height:12),
            ElevatedButton(onPressed: _save, child: Text('Salvar'))
          ]),
        ),
      ),
    );
  }
}
