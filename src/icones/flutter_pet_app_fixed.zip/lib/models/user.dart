class User {
  final String id;
  final String name;
  final String email;
  final bool isAdmin;
  String phone;
  String address;

  User({required this.id, required this.name, required this.email, this.isAdmin=false, this.phone='', this.address=''});
}
