class Service {
  String id;
  String title;
  String description;
  double price;
  Duration duration;

  Service({required this.id, required this.title, this.description='', required this.price, required this.duration});
}
