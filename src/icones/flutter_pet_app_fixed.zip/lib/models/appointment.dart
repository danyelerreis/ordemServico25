class Appointment {
  String id;
  String petId;
  String serviceId;
  DateTime dateTime;
  String userId;

  Appointment({required this.id, required this.petId, required this.serviceId, required this.dateTime, required this.userId});
}
