class Pet {
  String id;
  String name;
  String species;
  String breed;
  int age;
  double weight;
  String photoUrl;

  Pet({required this.id, required this.name, required this.species, required this.breed, required this.age, required this.weight, this.photoUrl = ''});
}
