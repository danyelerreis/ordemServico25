import 'package:flutter/material.dart';
import 'dart:math';
import '../models/pet.dart';
import '../models/service.dart';
import '../models/appointment.dart';

// Simple in-memory app state
class AppState extends ChangeNotifier {
  final List<Pet> _pets = [];
  final List<Service> _services = [];
  final List<Appointment> _appointments = [];
  final Set<String> _favorites = {};
  bool _loading = false;

  bool get loading => _loading;
  List<Pet> get pets => List.unmodifiable(_pets);
  List<Service> get services => List.unmodifiable(_services);
  List<Appointment> get appointments => List.unmodifiable(_appointments);
  Set<String> get favorites => _favorites;

  AppState() {
    _seedServices();
    _seedPets();
  }

  void _seedServices() {
    _services.addAll([
      Service(id: 's1', title: 'Banho Simples', description: 'Banho e secagem', price: 50.0, duration: Duration(minutes: 40)),
      Service(id: 's2', title: 'Tosa', description: 'Tosa completa', price: 80.0, duration: Duration(minutes: 60)),
      Service(id: 's3', title: 'Vacinação', description: 'Vacinas essenciais', price: 120.0, duration: Duration(minutes: 20)),
      Service(id: 's4', title: 'Consulta Veterinária', description: 'Avaliação clínica', price: 150.0, duration: Duration(minutes: 30)),
    ]);
  }

  void _seedPets() {
    _pets.addAll([
      Pet(id: 'p1', name: 'Rex', species: 'Cão', breed: 'Vira-lata', age: 3, weight: 12.5, photoUrl: ''),
      Pet(id: 'p2', name: 'Mimi', species: 'Gato', breed: 'Siamês', age: 2, weight: 4.0, photoUrl: ''),
    ]);
  }

  // CRUD Pets
  void addPet(Pet pet) {
    _pets.add(pet);
    notifyListeners();
  }

  void updatePet(Pet pet) {
    int idx = _pets.indexWhere((p) => p.id == pet.id);
    if (idx >= 0) {
      _pets[idx] = pet;
      notifyListeners();
    }
  }

  void removePet(String id) {
    _pets.removeWhere((p) => p.id == id);
    notifyListeners();
  }

  // Appointments - avoid duplicates same service/pet/dateTime
  String _randomId(String prefix) => '${prefix}_${Random().nextInt(100000)}';

  bool canSchedule(String petId, String serviceId, DateTime dt) {
    return !_appointments.any((a) => a.petId == petId && a.serviceId == serviceId && a.dateTime == dt);
  }

  bool addAppointment(String petId, String serviceId, DateTime dt, String userId) {
    if (!canSchedule(petId, serviceId, dt)) return false;
    final ap = Appointment(id: _randomId('ap'), petId: petId, serviceId: serviceId, dateTime: dt, userId: userId);
    _appointments.add(ap);
    notifyListeners();
    return true;
  }

  void removeAppointment(String id) {
    _appointments.removeWhere((a) => a.id == id);
    notifyListeners();
  }

  // Favorites
  void toggleFavorite(String serviceId) {
    if (_favorites.contains(serviceId))
      _favorites.remove(serviceId);
    else
      _favorites.add(serviceId);
    notifyListeners();
  }

  // Simple loading helpers
  void setLoading(bool v) {
    _loading = v;
    notifyListeners();
  }
}
