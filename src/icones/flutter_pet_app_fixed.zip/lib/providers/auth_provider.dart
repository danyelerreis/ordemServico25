import 'package:flutter/material.dart';
import '../models/user.dart';

class AuthProvider extends ChangeNotifier {
  User? _user;

  User? get user => _user;
  bool get isAuthenticated => _user != null;

  // Mock login with fixed credentials
  Future<bool> login(String email, String password) async {
    await Future.delayed(Duration(milliseconds: 500)); // simulate loading
    if (email == 'admin@gmail.com' && password == 'admin123') {
      _user = User(id: 'u_admin', name: 'Administrador', email: email, isAdmin: true, phone: '', address: '');
      notifyListeners();
      return true;
    } else if (email == 'usuario@gmail.com' && password == 'user123') {
      _user = User(id: 'u_user', name: 'Usuário', email: email, isAdmin: false, phone: '', address: '');
      notifyListeners();
      return true;
    }
    return false;
  }

  void logout() {
    _user = null;
    notifyListeners();
  }

  // Simple update profile
  void updateProfile({String? name, String? phone, String? address}) {
    if (_user != null) {
      _user = User(
        id: _user!.id,
        name: name ?? _user!.name,
        email: _user!.email,
        isAdmin: _user!.isAdmin,
        phone: phone ?? _user!.phone,
        address: address ?? _user!.address,
      );
      notifyListeners();
    }
  }
}
