import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'providers/auth_provider.dart';
import 'providers/app_state.dart';
import 'screens/splash_screen.dart';
import 'screens/login_screen.dart';
import 'screens/home_screen.dart';
import 'screens/admin_panel.dart';
import 'screens/pet_form_screen.dart';
import 'screens/service_list_screen.dart';
import 'screens/service_detail_screen.dart';
import 'screens/appointment_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider<AuthProvider>(create: (_) => AuthProvider()),
        ChangeNotifierProvider<AppState>(create: (_) => AppState()),
      ],
      child: Consumer<AuthProvider>(
        builder: (context, auth, _) {
          return MaterialApp(
            title: 'Agenda & Serviços Pet',
            theme: ThemeData(
              primarySwatch: Colors.teal,
              visualDensity: VisualDensity.adaptivePlatformDensity,
            ),
            initialRoute: '/',
            routes: {
              '/': (ctx) => SplashScreen(),
              '/login': (ctx) => LoginScreen(),
              '/home': (ctx) => HomeScreen(),
              '/admin': (ctx) => AdminPanel(),
              '/pet_form': (ctx) => PetFormScreen(),
              '/services': (ctx) => ServiceListScreen(),
              '/service_detail': (ctx) => ServiceDetailScreen(),
              '/appointment': (ctx) => AppointmentScreen(),
            },
          );
        },
      ),
    );
  }
}
