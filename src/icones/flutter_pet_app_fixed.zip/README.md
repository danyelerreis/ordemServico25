# Flutter Pet Agenda & Serviços (Web) - Mock Project

## Overview
This is a scaffold Flutter web app implementing an Agenda & Serviços Pet system (banho/tosa) with a mock in-memory backend.
It was created to satisfy a professor checklist and evaluation criteria:
- Mock login (fixed credentials) with protected routes.
- Listing with search/filter + detail screen.
- Forms with validation (create/edit pets & appointments).
- CRUD in memory.
- Global state with Provider for favorites/reservations.
- UI feedback: Snackbars, badges, loading indicators.
- Minimal responsiveness for web/desktop.
- Git repository tags: `v0.9` (partial) and `v1.0` (final) - create these locally after reviewing.

## Credentials
- Admin: `admin@gmail.com` / `admin123` (has admin panel access)
- User: `usuario@gmail.com` / `user123` (regular user)

## How to run
1. Ensure Flutter is installed and supports web: `flutter channel stable` and `flutter upgrade`.
2. From project root: `flutter pub get`
3. Run: `flutter run -d chrome --web-renderer html`

## What is included
- `lib/main.dart` - app entry with Provider and routes.
- `lib/models` - simple model classes (User, Pet, Service, Appointment).
- `lib/providers` - AppState and AuthProvider using ChangeNotifier.
- `lib/screens` - Splash, Login, Home, Service List, Detail, Pet Form, Admin Panel, Appointment screens.
- `lib/widgets` - reusable widgets.

## Git & Tags
Initialize git, commit, and create tags:
```
git init
git add .
git commit -m "v0.9 - initial scaffold"
git tag v0.9
# implement final touches...
git commit -am "v1.0 - final"
git tag v1.0
```

## Notes & Limitations
- Image upload is simplified: for web it's recommended to use `file_picker` or `image_picker_for_web`. The scaffold uses a simple URL field for pet photos to keep dependencies minimal.
- Notifications/reminders are mocked as scheduled items in the app state; production would require backend and push notifications.

Feel free to request expansions: fuller admin CRUD, calendar UI package integration, file upload support, or conversion to Riverpod.
